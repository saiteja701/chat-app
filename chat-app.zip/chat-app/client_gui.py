import socket
import threading
import tkinter as tk
from tkinter import simpledialog, scrolledtext, messagebox

HOST = '127.0.0.1'
PORT = 5555

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

class ChatClient:
    def __init__(self, master):
        self.master = master
        master.title("Chat App (Client)")

        self.chat_log = scrolledtext.ScrolledText(master, state='disabled', wrap=tk.WORD)
        self.chat_log.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        self.entry = tk.Entry(master)
        self.entry.pack(padx=10, pady=(0, 10), fill=tk.X)
        self.entry.bind("<Return>", self.send_message)

        self.username = ""
        self.connect_to_server()

        self.receive_thread = threading.Thread(target=self.receive_messages)
        self.receive_thread.daemon = True
        self.receive_thread.start()

    def connect_to_server(self):
        try:
            client_socket.connect((HOST, PORT))
        except:
            messagebox.showerror("Error", "Unable to connect to server.")
            self.master.quit()
            return

        choice = simpledialog.askstring("Login/Register", "Enter 1 to Login or 2 to Register")
        client_socket.send(choice.encode())

        self.username = simpledialog.askstring("Username", "Enter your username:")
        client_socket.send(self.username.encode())

        password = simpledialog.askstring("Password", "Enter your password:", show='*')
        client_socket.send(password.encode())

    def send_message(self, event=None):
        message = self.entry.get()
        self.entry.delete(0, tk.END)
        if message:
            try:
                client_socket.send(message.encode())
            except:
                messagebox.showerror("Error", "Message failed to send.")

    def receive_messages(self):
        while True:
            try:
                msg = client_socket.recv(1024).decode()
                self.chat_log.config(state='normal')
                self.chat_log.insert(tk.END, msg + "\n")
                self.chat_log.config(state='disabled')
                self.chat_log.yview(tk.END)
            except:
                break

root = tk.Tk()
client = ChatClient(root)
root.mainloop()

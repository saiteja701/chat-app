import socket
import threading
import hashlib
import os

clients = {}
users_file = "users.txt"
chat_log = "chat_history.txt"

# Load existing users from file
def load_users():
    if not os.path.exists(users_file):
        return {}
    with open(users_file, "r") as f:
        lines = f.read().splitlines()
    return dict(line.split(":", 1) for line in lines)

# Save a new user
def save_user(username, password_hash):
    with open(users_file, "a") as f:
        f.write(f"{username}:{password_hash}\n")

# Log a message to chat history
def log_message(message):
    with open(chat_log, "a") as f:
        f.write(message + "\n")

# Send a message to all users except the sender
def broadcast(message, sender_username):
    log_message(message)
    for user, sock in clients.items():
        if user != sender_username:
            try:
                sock.send(message.encode())
            except:
                pass  # Ignore broken connections

# Handle each client after they connect
def handle_client(client_socket, addr):
    client_socket.send("Do you want to (1) Login or (2) Register? ".encode())
    choice = client_socket.recv(1024).decode().strip()

    users = load_users()
    authenticated = False

    while not authenticated:
        client_socket.send("Enter username: ".encode())
        username = client_socket.recv(1024).decode().strip()

        client_socket.send("Enter password: ".encode())
        password = client_socket.recv(1024).decode().strip()
        password_hash = hashlib.sha256(password.encode()).hexdigest()

        if choice == "1":  # Login
            if username in users and users[username] == password_hash:
                client_socket.send(f"Login successful. Welcome, {username}!\n".encode())
                authenticated = True
            else:
                client_socket.send("Invalid credentials. Try again.\n".encode())
        elif choice == "2":  # Register
            if username in users:
                client_socket.send("Username already exists.\n".encode())
            else:
                save_user(username, password_hash)
                client_socket.send("Registration successful! You're now logged in.\n".encode())
                authenticated = True
        else:
            client_socket.send("Invalid option. Choose 1 or 2.\n".encode())

    clients[username] = client_socket
    print(f"[NEW] {username} connected from {addr}")

    while True:
        try:
            msg = client_socket.recv(1024).decode()

            if msg.strip() == "/history":
                try:
                    with open(chat_log, "r") as f:
                        history = f.read()
                    client_socket.send(f"--- Chat History ---\n{history}".encode())
                except:
                    client_socket.send("[Server] No chat history available.".encode())

            elif msg.startswith("/msg"):
                _, recipient, *content = msg.split()
                message = ' '.join(content)
                if recipient in clients:
                    clients[recipient].send(f"[Private] {username}: {message}".encode())
                    log_message(f"[Private] {username} -> {recipient}: {message}")
                else:
                    client_socket.send("[Server] User not found.".encode())

            else:
                full_msg = f"{username}: {msg}"
                broadcast(full_msg, username)

        except:
            print(f"[DISCONNECT] {username}")
            clients.pop(username)
            client_socket.close()
            break

# Start the server
def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("0.0.0.0", 5555))
    server.listen()
    print("[SERVER STARTED] Listening on port 5555...")

    while True:
        client_socket, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(client_socket, addr))
        thread.start()

start_server()
